#pragma once
#ifndef __Spout__
#define __Spout__


#include "SpoutSender.h"
#include "SpoutReceiver.h"

//	All documentation in the SDK pdf = SpoutSDK.pdf

#endif